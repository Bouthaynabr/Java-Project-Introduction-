package myPackage;

public class FirstJavaProgram {

	public static void main(String[] args) {
		
		System.out.println("This is my first Program");

	}

}
