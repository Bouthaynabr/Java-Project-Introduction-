package myPackage;

public class Operators {

	public static void main(String[] args) {
		int a =10;
		int b=20;
		
		//Arithmetic operators --> + - * %
		System.out.println("-----Arithmetic Operators-----");
		System.out.println("Sum of a and b is: " +(a+b));
		System.out.println("Diff of a and b is:" +(a-b)); //Without () will do Concat
		
		//Relational Operators --> == <> <= >= !=
		//Always return boolean value
		System.out.println("------Relational Operators----");
		System.out.println(a == b); //False
		System.out.println(a > b);
		System.out.println(a != b);

		//Logical Operators --> && || !
		//Works between boolean 
		boolean x = true; // true =1
		boolean y = false; //false=0
		System.out.println("-----Logical Operators-----");
		System.out.println(x && y); // ET c'est la multiplication ---> false
		System.out.println(x || y); //OU c'est l'addition ---> true
		System.out.println(!x); //l'inverse de cette valeur ---> false
		System.out.println(!y); //l(inverse de cette valeur ---> true
		
		//Increment/Decrement Operators --> ++ --
		System.out.println("--------Increment/Decrement Operators--------");
		a=10;
		a++; // a= a+1 ou a+=1 //a+=1;
		System.out.println(a); 
		
		b= 20 ;
		b=b-1; // b--;
		System.out.println(b);
		//System.out.println(!x); //l'inverse de cette valeur ---> false
		//System.out.println(!y); //l(inverse de cette valeur ---> true
		
	}

}
