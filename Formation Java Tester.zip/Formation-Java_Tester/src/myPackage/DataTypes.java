package myPackage;

public class DataTypes {

	public static void main(String[] args) {
		int a = 10; //Primitives
		double d = 10.5; 
		char c = 'H' ;
		boolean b =false;
		String s = "Welcome"; //Derived
		System.out.println(a);
		System.out.println(d);
		System.out.println(c);
		System.out.println(b);
		System.out.println(s);

	}

}
